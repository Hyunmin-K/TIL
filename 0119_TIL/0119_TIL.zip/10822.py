# 더하기
s = list(map(int,input().split(',')))
print(sum(s))