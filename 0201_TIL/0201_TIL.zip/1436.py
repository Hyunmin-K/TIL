#영화감독 숌

n = int(input())
i = 0
cnt = 0
while True:
    i +=1
    if '666' in str(i):
        cnt+=1
    if cnt == n:
        break
print(i)